<?php

// Space Language Pack for Discuz! Version 1.0.0
// Translated by Monkey

$spacelanguage = array
(
	'space' => '的个人空间',
	'userinfo' => '个人信息',
	'calendar' => '日历',
	'mythreads' => '主题',
	'myreplies' => '回复',
	'myrewards' => '悬赏',
	'mytrades' => '店铺',
	'myvideos' => '视频',
	'mytradestick' => '推荐商品',
	'mytradetypes' => '店铺栏目',
	'mycounters' => '柜台',
	'tradeinfo' => '店铺介绍',
	'myblogs' => '文集',
	'myfriends' => '好友',
	'myfavforums' => '收藏的版块',
	'myfavthreads' => '收藏的帖子',
	'postblog' => '发表文集',
	'hotblog' => '最热的 5 篇文集',
	'lastpostblog' => '最新回复的 5 篇文集'
);

?>